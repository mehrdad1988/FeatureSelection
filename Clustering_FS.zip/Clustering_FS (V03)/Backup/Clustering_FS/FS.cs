﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Clustering_FS
{
    class FS
    {
        double[,] C;
        double[] Cor;
        Random Rand = new Random();

        List<Data> Train_Data;
        List<Data> Valid_Data;
        List<Data> Test_Data;
        List<Data> FS_Test_Data;
        List<Data> FS_Test_Train;
        List<Data> FS_Test_Test;
        List<int> Similar;
        List<int> Disimilar;
        int[] Result;
        double[] IG;
        List<double>[] Cum_IG;
        public double Final_Acc;

        int Iteration;
        int Pop_Size;
        double Crossover;
        double Mutation;
        int Num;
        int Type;
        int K;

        int Iteration_NN;
        double Alpha;
        int Hidden;

        DataGridView Dg;
        bool Print;

        List<int>[] Cluster;

        public FS(List<Data> train, List<Data> valid, List<Data> test, double crs, double mut, int it, int pop,int k, int type, int it_nn, double alfa, int hid, double[] ig, DataGridView dg)
        {
            Train_Data = train;
            Valid_Data = valid;
            Test_Data = test;
            IG = ig;

            Iteration = it;
            Pop_Size = pop;
            Mutation = mut;
            Crossover = crs;
            Type = type;
            K=k;

            Iteration_NN = it_nn;
            Alpha = alfa;
            Hidden = hid;

            Num = Train_Data[0].Att.Length;

            C = new double[Num, Num];
            Cor = new double[Num];

            Cluster = new List<int>[K];
            Cum_IG = new List<double>[K];
            for (int i = 0; i < K; i++)
            {
                Cluster[i] = new List<int>();
                Cum_IG[i] = new List<double>();
            }

                Dg = dg;
        }

        public List<Chromosome> Run_FS()
        {
            List<Chromosome> result = new List<Chromosome>();
            FS_Test_Data = new List<Data>();
            FS_Test_Train = new List<Data>();
            FS_Test_Test = new List<Data>();
            
            Calc_Similar_Disimilar();
            Clac_Cluster();
            Calc_Cum();
            Calc_Cor();
            Genetic GA = new Genetic(Iteration, Crossover, Mutation, Pop_Size, Type, Num, K, Dg, 1, Train_Data, Valid_Data, Cluster,Result,Cor,IG,Iteration_NN, Alpha, Hidden);
            result = GA.DoMating();
            for (int i = 0; i < Test_Data.Count; i++)
            {
                Data D = new Data();
                D.Class = Test_Data[i].Class;
                D.Number = Test_Data[i].Number;
                D.Att = new double[K];
                int index = 0;
                for (int j = 0; j < Num; j++)
                {
                    if (result[result.Count - 1].genes[j] == 1)
                    {
                        D.Att[index] = Test_Data[i].Att[j];
                        index++;
                    }
                }
                FS_Test_Data.Add(D);
            }
            List<int> l = new List<int>();
            for (int i = 0; i < Test_Data.Count; i++)
                l.Add(i);
            for (int i = 0; i < Convert.ToInt32(0.66 * Test_Data.Count); i++)
            {
                int index = Rand.Next(l.Count);
                FS_Test_Train.Add(Test_Data[l[index]]);
                l.RemoveAt(index);
            }

            for (int i = Convert.ToInt32(0.66 * Test_Data.Count); i <  Test_Data.Count; i++)
            {
                int index = Rand.Next(l.Count);
                FS_Test_Test.Add(Test_Data[l[index]]);
                l.RemoveAt(index);
            }
            //Run_NN_FS();
            return result;
        }

        public void Calc_Cor()
        {
            double[] mean = new double[Num];
            for (int j = 0; j < Num; j++)
            {
                for (int i = 0; i < Train_Data.Count; i++)
                {
                    mean[j] += Train_Data[i].Att[j];
                }
                mean[j] /= Train_Data.Count;
            }

            for (int i = 0; i < Num; i++)
            {
                for (int j = 0; j < Num; j++)
                {
                    double Sigma1 = 0;
                    double Sigma2 = 0;
                    double Sigma3 = 0;

                    for (int m = 0; m < Train_Data.Count; m++)
                    {
                        Sigma1 += (Train_Data[m].Att[i] - mean[i]) * (Train_Data[m].Att[j] - mean[j]);
                        Sigma2 += Math.Pow(Train_Data[m].Att[i] - mean[i], 2);
                        Sigma3 += Math.Pow(Train_Data[m].Att[j] - mean[j], 2);

                    }
                    C[i, j] = Sigma1 / ((Math.Sqrt(Sigma2) * (Math.Sqrt(Sigma3))));
                }
            }

            for (int i = 0; i < Num; i++)
            {
                for (int j = 0; j < Num; j++)
                {
                    if (i != j)
                        Cor[i] += Math.Abs(C[i, j]);
                }
                Cor[i] /= Num - 1;
            }
        }

        public void Clac_Cluster()
        {
            List<Data> Train_And_Valid=new List<Data>();
            for(int i=0;i<Train_Data.Count;i++)
                Train_And_Valid.Add(Train_Data[i]);

            for(int i=0;i<Valid_Data.Count;i++)
                Train_And_Valid.Add(Valid_Data[i]);

            double[,] Data_Clustering=new double[Num,Train_And_Valid.Count];
            for (int i = 0; i < Num; i++)
                for (int j = 0; j < Train_And_Valid.Count; j++)
                    Data_Clustering[i, j] = Train_And_Valid[j].Att[i];

            Clustering cluster = new Clustering(Data_Clustering, K, Train_And_Valid.Count, Num, 50, 1);
            Result = cluster.Run_Clustering();

            for (int i = 0; i < Result.Length; i++)
                Cluster[Result[i]].Add(i);

            int end = 0;

        }

        public void Calc_Similar_Disimilar()
        {
            double[] Copy_Cor = new double[Num];
            List<int> Sorted_List = new List<int>();
            double h;
            int h_int;


            for (int i = 0; i < Num; i++)
                Sorted_List.Add(i);

            for (int i = 0; i < Num; i++)
                Copy_Cor[i] = Cor[i];

            for (int i = 0; i < Num; i++)
            {
                for (int j = i; j < Num; j++)
                {
                    if (Copy_Cor[i] > Copy_Cor[j])
                    {
                        h = Copy_Cor[i];
                        Copy_Cor[i] = Copy_Cor[j];
                        Copy_Cor[j] = h;

                        h_int = Sorted_List[i];
                        Sorted_List[i] = Sorted_List[j];
                        Sorted_List[j] = h_int;
                    }
                }
            }
            Similar = new List<int>();
            Disimilar = new List<int>();

            for (int i = 0; i < Convert.ToInt32(Num / 2); i++)
                Disimilar.Add(Sorted_List[i]);
            for (int i = Convert.ToInt32(Num / 2); i < Num; i++)
                Similar.Add(Sorted_List[i]);
        }

        public double Run_NN()
        {
            NN nn = new NN(Train_Data, Valid_Data, Iteration_NN, Hidden, Alpha, Dg, Print);
            nn.Train();
            double acc = nn.Test();
            MessageBox.Show(acc.ToString());
            return acc;
        }

        public double Run_NN_FS()
        {
            NN nn = new NN(FS_Test_Train, FS_Test_Test, Iteration_NN, Hidden, Alpha, Dg, Print);
            nn.Train();
            double acc = nn.Test();
            Final_Acc = acc;
            string S;
            S = "Accuracy: ";
            S += acc.ToString();
            MessageBox.Show(S);
            return acc;
        }

        public double Run_After_Clusterin()
        {
            List<int> Selected_Feature = new List<int>();
            Random Rand=new Random();
            
            for (int i = 0; i < K; i++)
            {
                Selected_Feature.Add(Cluster[i][Rand.Next(Cluster[i].Count)]);
            }

            List<Data> New_Train = new List<Data>();
            List<Data> New_Valid = new List<Data>();
            for (int i = 0; i < Train_Data.Count; i++)
            {
                Data D = new Data();
                D.Att = new double[K];
                D.Class=Train_Data[i].Class;
                int index = 0;
                for (int j = 0; j < Num; j++)
                {
                    if (Selected_Feature.Contains(j))
                    {
                        D.Att[index] = Train_Data[i].Att[j];
                        index++;
                    }
                }
                New_Train.Add(D);
            }

            for (int i = 0; i < Valid_Data.Count; i++)
            {
                Data D = new Data();
                D.Att = new double[K];
                D.Class = Valid_Data[i].Class;
                int index = 0;
                for (int j = 0; j < Num; j++)
                {
                    if (Selected_Feature.Contains(j))
                    {
                        D.Att[index] = Valid_Data[i].Att[j];
                        index++;
                    }
                }
                New_Valid.Add(D);
            }


            NN nn = new NN(New_Train, New_Valid, Iteration_NN, Hidden, Alpha, Dg, Print);
            nn.Train();
            double acc = nn.Test();
            MessageBox.Show(acc.ToString());
            return acc;
        }

        void Calc_Cum()
        {
            double[] sum = new double[K];
            for (int k = 0; k < K; k++)
            {
                for (int i = 0; i < Cluster[k].Count; i++)
                    sum[k] += IG[Cluster[k][i]];
            }

            
            for (int k = 0; k < K; k++)
            {
                double Sum_Cum = 0;
                for (int i = 0; i < Cluster[k].Count; i++)
                {
                    Sum_Cum += IG[Cluster[k][i]];
                    Cum_IG[k].Add(Sum_Cum / sum[k]);
                }
            }
        }

        int Select_From_Cluster(int c)
        {
            double r = Rand.NextDouble();
            int n = Cluster[c].Count;
            int index=0;
            for (int i = 0; i < n; i++)
            {
                index = i;
                if (r > Cum_IG[c][i])
                    break;
            }
            return index;
        }

        public double Check_SVM()
        {
            SVM svmmm = new SVM(Test_Data);
            svmmm.Train();
            return svmmm.Test();
        }

        public double Check_KNN()
        {
            KNN knn = new KNN(Test_Data, 5);
            return knn.Test();
        }

        public void Clac_Diff_Classifier(ref double Acc_NN, ref double Acc_KNN, ref double Acc_SVM)
        {
            NN nn = new NN(FS_Test_Train, FS_Test_Test, Iteration_NN, Hidden, Alpha, Dg, Print);
            nn.Train();
            Acc_NN = nn.Test();

            KNN knn = new KNN(FS_Test_Data, 5);
            Acc_KNN= knn.Test();


            SVM svmmm = new SVM(FS_Test_Data);
            svmmm.Train();
            Acc_SVM = svmmm.Test();
        }
    }
}