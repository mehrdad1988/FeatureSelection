﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clustering_FS
{
    class Chromosome
    {

        public int[] genes;
        public double Fitness;
        public double cumulative_fitness;
        public int Xd;
        public int Xs;
        public List<int>[] Cluster;

        public Chromosome()
        {

        } 

    }
}
