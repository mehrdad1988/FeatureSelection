﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenCLTemplate.MachineLearning;
using System.Windows.Forms;

namespace Clustering_FS
{
    class SVM
    {
        List<Data> DataSet;
        List<Data> Train_Data;
        List<Data> Test_Data;

        TrainingSet TrainSet;
        TrainingSet TestSet;
        MultiClassSVM svmmm;
        ProblemConfig cfg;
        Random Rand = new Random();
        int Train_Count;
        int Test_Count;

        public SVM(List<Data> data)
        {
            DataSet = data;
            cfg = new ProblemConfig(0.1f, 20f, 1e-3f, 10);
            Train_Count = Convert.ToInt32(DataSet.Count * 0.66);
            Test_Count = DataSet.Count - Train_Count;
        }

        public void Train()
        {
            Set_Train_And_Test();
            Set_Train_Data_SVM();
            svmmm = new MultiClassSVM(TrainSet, cfg);
            //svmmm = new MultiClassSVM(TrainSet, cfg);
        }

        public double Test()
        {

            int Num_Success = 0;
            for (int i = 0; i < Test_Count; i++)
            {
                int Inclass = 0, Outclass = 0;
                float val;
                float num = svmmm.Classify(TestSet.trainingArray[i], out val);
                Outclass = Convert.ToInt32(num);
                Inclass = Convert.ToInt32(TestSet.trainingArray[i].y);
                if (Inclass == Outclass)
                    Num_Success++;
            }
            return (double)(Num_Success) / (double)(Test_Count);
        }

        void Set_Train_Data_SVM()
        {
            TrainSet = new TrainingSet();
            TestSet = new TrainingSet();
            Random r = new Random();
            int c = DataSet.Count;
            int Num_Attr=Train_Data[0].Att.Length;

            for (int i = 0; i < Train_Count; i++)
            {
                float[] feature = new float[Num_Attr];
                for (int j = 0; j < Num_Attr; j++)
                    feature[j] = (float)(Train_Data[i].Att[j]);
                TrainSet.addTrainingUnit(new TrainingUnit(feature,1));
                TrainSet.trainingArray[i].y = Train_Data[i].Class;
            }

            for (int i = 0; i < Test_Count; i++)
            {
                float[] feature = new float[Num_Attr];
                for (int j = 0; j < Num_Attr; j++)
                    feature[j] = (float)(Test_Data[i].Att[j]);
                TestSet.addTrainingUnit(new TrainingUnit(feature, 1));
                TestSet.trainingArray[i].y = Train_Data[i].Class;
            }
        }

        void Set_Train_And_Test()
        {
            List<int> Temp = new List<int>();
            Train_Data = new List<Data>();
            Test_Data = new List<Data>();


            for (int i = 0; i < DataSet.Count; i++)
                Temp.Add(i);

            for (int i = 0; i < Train_Count; i++)
            {
                int index = Rand.Next(Temp.Count);
                Train_Data.Add(DataSet[Temp[index]]);
                Temp.RemoveAt(index);
            }

            for (int i = Train_Count; i <  DataSet.Count; i++)
            {
                int index = Rand.Next(Temp.Count);
                Test_Data.Add(DataSet[Temp[index]]);
                Temp.RemoveAt(index);
            }


            for (int i = 0; i < Train_Count; i++)
                if (Train_Data[i].Class == -1)
                    Train_Data[i].Class = 0;

            for (int i = 0; i < Test_Count; i++)
                if (Test_Data[i].Class == -1)
                    Test_Data[i].Class = 0;

        }



    }
}
