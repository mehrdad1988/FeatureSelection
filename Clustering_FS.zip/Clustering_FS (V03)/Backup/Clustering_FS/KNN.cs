﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clustering_FS
{
    class KNN
    {
        List<Data> DataSet;
        List<Data> Train_Data;
        List<Data> Test_Data;
        int k;
        int Train_Count;
        int Test_Count;
        int Num_Attr;
        Random Rand = new Random();

        public KNN(List<Data> Data, int kk)
        {
            DataSet = Data;
            k = kk;
            Train_Count = Convert.ToInt32(DataSet.Count*0.66);
            Test_Count = Data.Count - Train_Count;
            Set_Train_And_Test();  
            Num_Attr = Data[0].Att.Length;

            for (int i = 0; i < Data.Count; i++)
                if (DataSet[i].Class == -1)
                    DataSet[i].Class = 0;

        }

        public double Test()
        {
            List<Data> K_Nearest_List = new List<Data>();
            int c=0;
            int True_Pridict=0;
            for (int i = 0; i < Test_Count; i++)
            {
                K_Nearest_List = K_Nearest(Test_Data[i]);
                c=Find_Class(K_Nearest_List);
                if (Test_Data[i].Class == c)
                    True_Pridict++;
            }
            return ((double)(True_Pridict) / (double)(Test_Count));
        }

        List<Data> K_Nearest(Data D)
        {
            List<Data> Result=new List<Data>();
            double[] Distance = new double[Train_Count];
            int[] Index = new int[Train_Count];
            int temp = 0;
            double temp_d = 0;
            for (int i = 0; i < Train_Count; i++)
            {
                Distance[i] = Calc_Distanc(D, Train_Data[i]);
                Index[i] = i;
            }

            for (int i = 0; i < Train_Count; i++)
            {
                for (int j = i; j < Train_Count; j++)
                {
                    if (Distance[i] > Distance[j])
                    {
                        temp = Index[i];
                        Index[i] = Index[j];
                        Index[j] = temp;

                        temp_d = Distance[i];
                        Distance[i] = Distance[j];
                        Distance[j] = temp_d;

                    }
                }
            }

            for (int i = 0; i < k; i++)
                Result.Add(Train_Data[Index[i]]);

            return Result;
        }

        int Find_Class(List<Data> D)
        {
            int n=DataSet[0].Number;
            int[] Num=new int[n];
            int c = 0;
            for (int i = 0; i < D.Count; i++)
            {
                c = D[i].Class;
                Num[c]++;
            }
            int result=0;
            int max=0;
            for (int i = 0; i < n; i++)
            {
                if (Num[i] > max)
                {
                    max = Num[i];
                    result = i;
                }
            }

            return result;
        }

        double Calc_Distanc(Data T1, Data T2)
        {
            double Sum=0;
            for (int i = 0; i < Num_Attr; i++)
                Sum += Math.Pow(T1.Att[i] - T2.Att[i],2);
            return Sum;
        }

        void Set_Train_And_Test()
        {
            List<int> Temp = new List<int>();
            Train_Data = new List<Data>();
            Test_Data = new List<Data>();
            Train_Data.Clear();
            Test_Data.Clear();


            for (int i = 0; i < DataSet.Count; i++)
                Temp.Add(i);

            for (int i = 0; i < Train_Count; i++)
            {
                int index = Rand.Next(Temp.Count);
                Train_Data.Add(DataSet[Temp[index]]);
                Temp.RemoveAt(index);
            }

            for (int i = Train_Count; i < DataSet.Count; i++)
            {
                int index = Rand.Next(Temp.Count);
                Test_Data.Add(DataSet[Temp[index]]);
                Temp.RemoveAt(index);
            }
        }

    }
}
