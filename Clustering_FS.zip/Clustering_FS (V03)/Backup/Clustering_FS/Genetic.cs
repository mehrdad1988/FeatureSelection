﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Clustering_FS
{
    class Genetic
    {

        private Random random = new Random();
        private int Num;
        int Elite;
        double Crossover;
        double Mutation;
        int Population;
        DataGridView DGV;
        int Iteration;
        List<Data> Train_Data;
        List<Data> Valid_Data;
        List<double>[] Cum_IG;
        double[] IG;
        int K;
        int Type;

        List<int> Similar;
        List<int> Disimilar;
        double mio;
        double delta;

        List<Chromosome> offspring = new List<Chromosome>();

        int Iteration_NN;
        int Hidden;
        double Alpha;
        double[] Cor;
        List<int>[] Cluster;
        int[] Result_Clustering;

        public Genetic(int it, double Crs, double Mut, int pop, int type, int num, int k, DataGridView dgv, int E, List<Data> T, List<Data> V,List<int>[] C,int[] Res_Clustering, double[] cor,double [] ig, int it_nn, double alfa, int hid)
        {
            Iteration = it;
            Crossover = Crs;
            Mutation = Mut;
            Population = pop;
            Type = type;
            Num = num;
            K = k;
            DGV = dgv;
            Elite = E;

            Train_Data = T;
            Valid_Data = V;
            Cor = cor;
            IG = ig;
            Cluster = C;
            Result_Clustering = Res_Clustering;

            Iteration_NN = it_nn;
            Hidden = hid;
            Alpha = alfa;
            delta = 0.65 * K;
            mio = 0.35 * K;
            Cum_IG = new List<double>[K];
            Calc_Cum();
        }

        public List<Chromosome> DoMating()
        {
            List<Chromosome> Result = new List<Chromosome>();
            Calc_Similar_Disimilar();
            if (Type == 2)
            {
                Calc_Similar_Disimilar_Threshold();
            }

            double totalFitness = 0;
            Chromosome ch = new Chromosome();
            List<Chromosome> initPopulation = new List<Chromosome>();
            List<Chromosome> Sorted_List = new List<Chromosome>();
            Init(ref initPopulation);
            CalcFitness(ref initPopulation, ref totalFitness);
            DGV.Rows.Clear();

            for (int generation = 0; generation < Iteration; generation++)
            {
                if (Type == 0)
                {
                    Pre_RuletteWheel(ref initPopulation, totalFitness);
                    Cross(ref initPopulation, Crossover);
                    Mutate(ref initPopulation, Mutation);
                    Calc_d_s(ref initPopulation);
                    CalcFitness(ref initPopulation, ref totalFitness);
                    Sorted_List.Clear();
                    for (int i = 0; i < initPopulation.Count; i++)
                        Sorted_List.Add(initPopulation[i]);
                    Sorted_List.Sort(new FitnessComparator());
                    Result.Add(Sorted_List[0]);
                }

                if (Type == 1)
                {
                    Pre_RuletteWheel(ref initPopulation, totalFitness);
                    Cross(ref initPopulation, Crossover);
                    Mutate(ref initPopulation, Mutation);
                    Calc_d_s(ref initPopulation);
                    Local(ref initPopulation);
                    CalcFitness(ref initPopulation, ref totalFitness);
                    Sorted_List.Clear();
                    for (int i = 0; i < initPopulation.Count; i++)
                        Sorted_List.Add(initPopulation[i]);
                    Sorted_List.Sort(new FitnessComparator());
                    Result.Add(Sorted_List[0]);
                }

                if (Type == 2)
                {
                    Pre_RuletteWheel(ref initPopulation, totalFitness);
                    Cross(ref initPopulation, Crossover);
                    Mutate(ref initPopulation, Mutation);
                    Calc_d_s(ref initPopulation);
                    Local(ref initPopulation);
                    CalcFitness(ref initPopulation, ref totalFitness);
                    Sorted_List.Clear();
                    for (int i = 0; i < initPopulation.Count; i++)
                        Sorted_List.Add(initPopulation[i]);
                    Sorted_List.Sort(new FitnessComparator());
                    Result.Add(Sorted_List[0]);
                }

                if (Type == 3)
                {
                    Pre_RuletteWheel(ref initPopulation, totalFitness);
                    Cross(ref initPopulation, Crossover);
                    Mutate(ref initPopulation, Mutation);
                    Calc_Cluster_Number(ref initPopulation);
                    Local_Cluster(ref initPopulation);
                    CalcFitness(ref initPopulation, ref totalFitness);
                    Sorted_List.Clear();
                    for (int i = 0; i < initPopulation.Count; i++)
                        Sorted_List.Add(initPopulation[i]);
                    Sorted_List.Sort(new FitnessComparator());
                    Result.Add(Sorted_List[0]);
                }

                if (Type == 4)
                {
                    Pre_RuletteWheel(ref initPopulation, totalFitness);
                    Cross(ref initPopulation, Crossover);
                    Mutate(ref initPopulation, Mutation);
                    Calc_Cluster_Number(ref initPopulation);
                    Local_Cluster_Portion(ref initPopulation);
                    CalcFitness(ref initPopulation, ref totalFitness);
                    Sorted_List.Clear();
                    for (int i = 0; i < initPopulation.Count; i++)
                        Sorted_List.Add(initPopulation[i]);
                    Sorted_List.Sort(new FitnessComparator());
                    Result.Add(Sorted_List[0]);
                }
            }
            initPopulation.Sort(new FitnessComparator());
            return Result;
        }

        public void Init(ref List<Chromosome> inint)
        {
            for (int i = 0; i < Population; i++)
            {
                Chromosome ch = new Chromosome();
                ch.genes = new int[Num];
                ch.Cluster = new List<int>[K];
                List<int> l = new List<int>();
                for (int m = 0; m < Num; m++)
                    l.Add(m);
                for (int k = 0; k < K; k++)
                {
                    int index = random.Next(l.Count);
                    ch.genes[l[index]] = 1;
                    l.RemoveAt(index);
                }
                inint.Add(ch);
            }
        }

        public void Cross(ref List<Chromosome> parents, double probability)
        {
            offspring.Clear();
            List<Chromosome> Sorted_list = new List<Chromosome>();
            Random Rand = new Random();

            if (Elite == 1)
            {
                for (int i = 0; i < parents.Count; i++)
                    Sorted_list.Add(parents[i]);
                Sorted_list.Sort(new FitnessComparator());
                offspring.Add(Sorted_list[0]);
            }

            for (int i = 0; i < parents.Count; i = i + 2)
            {
                if (Check_random(probability))
                {
                    int Random_Point = Rand.Next(1, Num);
                    Chromosome parentX = AssayRuletteWheel(parents);
                    Chromosome parentY = AssayRuletteWheel(parents);
                    Chromosome child1 = new Chromosome();
                    Chromosome child2 = new Chromosome();

                    int[] intit_child1 = new int[Num];
                    int[] intit_child2 = new int[Num];

                    for (int j = 0; j < Random_Point; j++)
                    {
                        intit_child1[j] = parentX.genes[j];
                        intit_child2[j] = parentY.genes[j];
                    }

                    for (int j = Random_Point; j < Num; j++)
                    {
                        intit_child1[j] = parentY.genes[j];
                        intit_child2[j] = parentX.genes[j];
                    }

                    Chromosome offSpr1 = new Chromosome();
                    Chromosome offSpr2 = new Chromosome();


                    offSpr1.genes = intit_child1.ToArray();
                    offSpr2.genes = intit_child2.ToArray();

                    offspring.Add(offSpr1);
                    offspring.Add(offSpr2);
                }

                else
                {
                    Chromosome parentX = AssayRuletteWheel(parents);
                    Chromosome parentY = AssayRuletteWheel(parents);
                    offspring.Add(parentX);
                    offspring.Add(parentY);
                }
            }

            while (offspring.Count > parents.Count)
            {
                offspring.RemoveAt((int)GetRandomVal(0, offspring.Count - 1));
            }
        }

        private void Pre_RuletteWheel(ref List<Chromosome> parents, double total)
        {
            double currentTotalFitness = 0;
            for (int i = 0; i < parents.Count; i++)
            {
                currentTotalFitness += parents[i].Fitness;
                Chromosome temp = parents[i];
                temp.cumulative_fitness = currentTotalFitness / (double)total;
                parents[i] = temp;
            }
        }

        private Chromosome AssayRuletteWheel(List<Chromosome> parents)
        {
            Chromosome selection = parents[0];
            double probability = random.NextDouble();
            for (int i = 0; i < parents.Count; i++)
            {
                selection = parents[i];
                if (parents[i].cumulative_fitness > probability)
                    break;

            }
            return selection;
        }

        public void Mutate(ref List<Chromosome> parents, double probability)
        {

            for (int i = 1; i < parents.Count; i++)
            {
                for (int mutatePosition = 0; mutatePosition < Num; mutatePosition++)
                {
                    if (Check_random(probability))
                    {
                        if (parents[i].genes[mutatePosition] == 0)
                            parents[i].genes[mutatePosition] = 1;
                        else
                            parents[i].genes[mutatePosition] = 0;
                    }
                }

            }

        }

        public double GetRandomVal(double min, double max)
        {
            return min + random.NextDouble() * (max - min);
        }

        private bool Check_random(double probability)
        {
            if (random.NextDouble() < probability)
                return true;
            else
                return false;
        }

        public void CalcFitness(ref List<Chromosome> chromosome, ref double totalFitness)
        {
            totalFitness = 0;
            for (int k = 0; k < chromosome.Count; k++)
            {
                List<Data> T_Data = new List<Data>();
                List<Data> V_Data = new List<Data>();

                int One_Nnumber = 0;
                for (int x = 0; x < chromosome[0].genes.Length; x++)
                    if (chromosome[k].genes[x] == 1)
                        One_Nnumber++;

                for (int i = 0; i < Train_Data.Count; i++)
                {
                    Data data = new Data();
                    data.Att = new double[One_Nnumber];
                    data.Class = Train_Data[i].Class;
                    int index = 0;
                    for (int j = 0; j < chromosome[0].genes.Length; j++)
                    {
                        if (chromosome[k].genes[j] == 1)
                        {
                            data.Att[index] = Train_Data[i].Att[j];
                            index++;
                        }
                    }
                    T_Data.Add(data);
                }

                for (int i = 0; i < Valid_Data.Count; i++)
                {
                    Data data = new Data();
                    data.Att = new double[One_Nnumber];
                    data.Class = Valid_Data[i].Class;
                    int index = 0;
                    for (int j = 0; j < chromosome[0].genes.Length; j++)
                    {
                        if (chromosome[k].genes[j] == 1)
                        {
                            data.Att[index] = Valid_Data[i].Att[j];
                            index++;
                        }
                    }
                    V_Data.Add(data);
                }
                NN nn = new NN(T_Data, V_Data, Iteration_NN, Hidden, Alpha, DGV, false);
                chromosome[k].Fitness = nn.Run_NN();
                totalFitness += chromosome[k].Fitness;
            }
        }

        public void Calc_Similar_Disimilar()
        {
            double[] Copy_Cor = new double[Num];
            List<int> Sorted_List = new List<int>();
            double h;
            int h_int;


            for (int i = 0; i < Num; i++)
                Sorted_List.Add(i);

            for (int i = 0; i < Num; i++)
                Copy_Cor[i] = Cor[i];

            for (int i = 0; i < Num; i++)
            {
                for (int j = i; j < Num; j++)
                {
                    if (Copy_Cor[i] > Copy_Cor[j])
                    {
                        h = Copy_Cor[i];
                        Copy_Cor[i] = Copy_Cor[j];
                        Copy_Cor[j] = h;

                        h_int = Sorted_List[i];
                        Sorted_List[i] = Sorted_List[j];
                        Sorted_List[j] = h_int;
                    }
                }
            }
            Similar = new List<int>();
            Disimilar = new List<int>();

            for (int i = 0; i < Convert.ToInt32(Num / 2); i++)
                Disimilar.Add(Sorted_List[i]);
            for (int i = Convert.ToInt32(Num / 2); i < Num; i++)
                Similar.Add(Sorted_List[i]);
        }

        public void Calc_Similar_Disimilar_Threshold()
        {
            double[] Copy_Cor = new double[Num];
            List<int> Sorted_List = new List<int>();
            double h;
            int h_int;


            for (int i = 0; i < Num; i++)
                Sorted_List.Add(i);

            for (int i = 0; i < Num; i++)
                Copy_Cor[i] = Cor[i];

            for (int i = 0; i < Num; i++)
            {
                for (int j = i; j < Num; j++)
                {
                    if (Copy_Cor[i] > Copy_Cor[j])
                    {
                        h = Copy_Cor[i];
                        Copy_Cor[i] = Copy_Cor[j];
                        Copy_Cor[j] = h;

                        h_int = Sorted_List[i];
                        Sorted_List[i] = Sorted_List[j];
                        Sorted_List[j] = h_int;
                    }
                }
            }
            Similar = new List<int>();
            Disimilar = new List<int>();
            Similar.Clear();
            Disimilar.Clear();
            double mean = (Cor[Sorted_List[Num - 1]] - Cor[Sorted_List[0]]) / 2;
            for (int i = 0; i < Num; i++)
            {
                if (Cor[Sorted_List[i]] > mean)
                    Similar.Add(Sorted_List[i]);
                else
                    Disimilar.Add(Sorted_List[i]);
            }
            int m = 0;
        }

        public void Calc_d_s(ref List<Chromosome> Ch)
        {
            int L = Ch[0].genes.Length;
            for (int i = 0; i < Ch.Count; i++)
            {
                int d = 0;
                int s = 0;
                for (int j = 0; j < L; j++)
                {
                    if (Ch[i].genes[j] == 1)
                    {
                        if (Disimilar.Contains(j))
                            d++;
                        if (Similar.Contains(j))
                            s++;
                    }
                }
                Ch[i].Xd = d;
                Ch[i].Xs = s;
            }
        }

        public void Calc_Cluster_Number(ref List<Chromosome> Ch)
        {
            int L = Ch[0].genes.Length;
            
            for (int i = 0; i < Ch.Count; i++)
            {
                for (int l = 0; l < K; l++)
                {
                    Ch[i].Cluster[l] = new List<int>();
                }
                for (int j = 0; j < L; j++)
                    if (Ch[i].genes[j] == 1)
                        Ch[i].Cluster[Result_Clustering[j]].Add(j);
            }
        }

        public void Local(ref List<Chromosome> Ch)
        {
            for (int i = 0; i < Ch.Count; i++)
            {
                if (Ch[i].Xd < delta)
                {
                    int index = 0;
                    for (int t = 0; t < Math.Round(delta - Ch[i].Xd); t++)
                    {
                        Ch[i].genes[Disimilar[index]] = 1;
                        index++;
                    }
                }

                if (Ch[i].Xs > mio)
                {
                    int index = Similar.Count - 1;
                    for (int t = 0; t < Math.Round(Ch[i].Xs - mio); t++)
                    {
                        Ch[i].genes[Similar[index]] = 0;
                        index--;
                    }
                }

                //if (Ch[i].Xd > delta)
                //{
                //    int index = 0;
                //    for (int t = 0; t < Ch[i].Xd - delta; t++)
                //    {
                //        Ch[i].genes[Disimilar[index]] = 1;
                //        index++;
                //    }
                //}

                //if (Ch[i].Xs < mio)
                //{
                //    int index = Similar.Count - 1;
                //    for (int t = 0; t < mio - Ch[i].Xs; t++)
                //    {
                //        Ch[i].genes[Similar[index]] = 0;
                //        index--;
                //    }
                //}

            }
        }

        public void Local_Cluster(ref List<Chromosome> Ch)
        {
            for (int i = 0; i < Ch.Count; i++)
            {
                for (int j = 0; j < K; j++)
                {
                    if (Ch[i].Cluster[j].Count>1)
                    {
                        //while (Ch[i].Cluster[j].Count>1)
                        //{
                        //    int r = random.Next(Ch[i].Cluster[j].Count);
                        //    int index = Ch[i].Cluster[j][r];
                        //    Ch[i].Cluster[j].RemoveAt(r);
                        //    Ch[i].genes[index] = 0;
                            
                        //}

                        int index = Ch[i].Cluster[j][Remove_From_Cluster(j,Ch[i])];
                        Ch[i].Cluster[j].Clear();
                        Ch[i].Cluster[j].Add(index);
                        for (int ii = 0; ii < Cluster[j].Count; ii++)
                            Ch[i].genes[Cluster[j][ii]] = 0;
                        Ch[i].genes[index] = 1;
                        
                    }

                    if (Ch[i].Cluster[j].Count < 1)
                    {
                        //int index = Cluster[j][random.Next(index = Cluster[j].Count)];
                        //Ch[i].Cluster[j].Add(index);
                        //Ch[i].genes[index] = 1;

                        int index = Cluster[j][Select_From_Cluster(j)];
                        Ch[i].Cluster[j].Add(index);
                        Ch[i].genes[index] = 1;
                    }
                }
            }
        }

        void Calc_Cum()
        {
            double[] sum = new double[K];
            for (int k = 0; k < K; k++)
            {
                for (int i = 0; i < Cluster[k].Count; i++)
                    sum[k] += IG[Cluster[k][i]];
            }


            for (int k = 0; k < K; k++)
            {
                Cum_IG[k] = new List<double>();
                double Sum_Cum = 0;
                for (int i = 0; i < Cluster[k].Count; i++)
                {
                    Sum_Cum += IG[Cluster[k][i]];
                    Cum_IG[k].Add(Sum_Cum / sum[k]);
                }
            }
        }

        int Select_From_Cluster(int c)
        {
            double r = random.NextDouble();
            int n = Cluster[c].Count;
            int index = 0;
            for (int i = 0; i < n; i++)
            {
                index = i;
                if (r < Cum_IG[c][i])
                    break;
            }
            return index;
        }

        int Remove_From_Cluster(int c, Chromosome ch)
        {
            
            int n=ch.Cluster[c].Count;
            double[] Cum_C = new double[n];
            double Sum=0;
            for (int i = 0; i < n; i++)
            {
                Sum += IG[ch.Cluster[c][i]];
            }
            double temp=0;
            for (int i = 0; i < n; i++)
            {
                temp += IG[ch.Cluster[c][i]];
                Cum_C[i] = temp / Sum;
            }
            int index=0;
            double r = random.NextDouble();
            for (int i = 0; i < n; i++)
            {
                index = i;
                if (r < Cum_C[i])
                    break;
            }
            return index;
        }

        public void Local_Cluster_Portion(ref List<Chromosome> Ch)
        {
            for (int i = 0; i < Ch.Count; i++)
            {
                for (int j = 0; j < K; j++)
                {
                    if ((Ch[i].Cluster[j].Count > (K * ((double)Cluster[j].Count / (double)Num))) && (Ch[i].Cluster[j].Count > 1))
                    {
                        while ((Ch[i].Cluster[j].Count > (K * ((double)Cluster[j].Count / (double)Num))) && (Ch[i].Cluster[j].Count > 1))
                        {
                            int r = random.Next(Ch[i].Cluster[j].Count);
                            int index = Ch[i].Cluster[j][r];
                            Ch[i].Cluster[j].RemoveAt(r);
                            Ch[i].genes[index] = 0;
                        }
                    }

                    if ((Ch[i].Cluster[j].Count < (K*((double)Cluster[j].Count/(double)Num))) || (Ch[i].Cluster[j].Count < 1))
                    {
                        while ((Ch[i].Cluster[j].Count < (K * ((double)Cluster[j].Count / (double)Num))) || (Ch[i].Cluster[j].Count < 1))
                        {
                            int index = Cluster[j][random.Next(index = Cluster[j].Count)];
                            Ch[i].Cluster[j].Add(index);
                            Ch[i].genes[index] = 1;
                        }
                    }
                }
            }
        }

        class FitnessComparator : Comparer<Chromosome>
        {
            public override int Compare(Chromosome x, Chromosome y)
            {
                if (x.Fitness == y.Fitness)
                    return 0;
                else if (x.Fitness < y.Fitness)
                    return 1;
                else
                    return -1;
            }
        }

    }
}
