﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Clustering_FS
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        int DataSet_Name;
        int Num_Attributes;
        int Num_Instance;
        int K;

        double[] IG;

        List<Data> DataSet = new List<Data>();
        List<Data> Train_Data = new List<Data>();
        List<Data> Valid_Data = new List<Data>();
        List<Data> Test_Data = new List<Data>();
        List<Data> Weka_Test_Data = new List<Data>();
        List<Data> Weka_Dataset = new List<Data>();
        List<int> Selected_Feature = new List<int>();
        List<int> Weka_List = new List<int>();
        String Name;

        StreamWriter SW;
        string AddressW;


        Random Rand = new Random();

        private void Miss_Handling()
        {
            double[] sum = new double[Num_Attributes];
            int[] num = new int[Num_Attributes];
            int[] class_num = new int[2];

            if (DataSet_Name == 0)
            {
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] != 0)
                        {
                            sum[j] += DataSet[i].Att[j];
                            num[j]++;
                        }
                    }
                }
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] == 0)
                        {
                            DataSet[i].Att[j] = sum[j] / num[j];
                            Weka_Dataset[i].Att[j] = sum[j] / num[j];
                        }
                    }
                }
            }

            if (DataSet_Name == 1)
            {
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] != 22)
                        {
                            sum[j] += DataSet[i].Att[j];
                            num[j]++;
                        }
                    }
                }
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] == 22)
                        {
                            DataSet[i].Att[j] = sum[j] / num[j];
                            Weka_Dataset[i].Att[j] = sum[j] / num[j];
                        }
                    }
                }
            }

            if (DataSet_Name == 2)
            {
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] != 22)
                        {
                            sum[j] += DataSet[i].Att[j];
                            num[j]++;
                        }
                    }
                }
                for (int i = 0; i < DataSet.Count; i++)
                {
                    for (int j = 0; j < Num_Attributes; j++)
                    {
                        if (DataSet[i].Att[j] == 22)
                        {
                            DataSet[i].Att[j] = sum[j] / num[j];
                            Weka_Dataset[i].Att[j] = sum[j] / num[j];
                        }
                    }
                }
            }
            int mmm = 0;
        }

        public void Create_DataSet(List<string> S, int num_instance, int num_att)
        {
            string[] temp;
            string str;

            if (DataSet_Name == 0)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Number = 2;
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 0; j < num_att; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[num_att] == "0")
                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 1)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Number = 2;
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 1; j <= num_att; j++)
                    {
                        Temp_Data.Att[j - 1] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[0] == "1")
                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 2)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Number = 2;
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 0; j < num_att; j++)
                    {
                        Temp_Data.Att[j] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[num_att] == "R")
                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }

            if (DataSet_Name == 3)
            {
                for (int i = 0; i < num_instance; i++)
                {
                    Data Temp_Data = new Data();
                    Temp_Data.Number = 2;
                    Temp_Data.Att = new double[num_att];
                    str = S[i];
                    temp = str.Split(',');
                    for (int j = 1; j < num_att+1; j++)
                    {
                        Temp_Data.Att[j-1] = Convert.ToDouble(temp[j]);
                    }
                    if (temp[num_att+1] == "2")
                        Temp_Data.Class = 0;
                    else
                        Temp_Data.Class = 1;
                    DataSet.Add(Temp_Data);
                }
            }
            int n=DataSet.Count;
            for (int i = 0; i < n; i++)
                Weka_Dataset.Add(DataSet[i]);
        }

        public void Creat_Train_Valid_Test()
        {
            List<int> Temp = new List<int>();
            for (int i = 0; i < DataSet.Count; i++)
                Temp.Add(i);

            for (int i = 0; i < Convert.ToInt32(0.5 * DataSet.Count); i++)
            {
                int index = Rand.Next(Temp.Count);
                Train_Data.Add(DataSet[Temp[index]]);
                Temp.RemoveAt(index);
            }

            for (int i = Convert.ToInt32(0.5 * DataSet.Count); i < Convert.ToInt32(0.75 * DataSet.Count); i++)
            {
                int index = Rand.Next(Temp.Count);
                Valid_Data.Add(DataSet[Temp[index]]);
                Temp.RemoveAt(index);
            }

            for (int i = Convert.ToInt32(0.75 * DataSet.Count); i < DataSet.Count; i++)
            {
                int index = Rand.Next(Temp.Count);
                Test_Data.Add(DataSet[Temp[index]]);
                Weka_Test_Data.Add(DataSet[Temp[index]]);
                Temp.RemoveAt(index);
            }
        }

        public void Data_Normalization()
        {
            double[] mean = new double[Num_Attributes];
            double[] max = new double[Num_Attributes];
            double[] min = new double[Num_Attributes];

            for (int j = 0; j < Num_Attributes; j++)
            {
                double maxx = double.MinValue;
                double minn = double.MaxValue;
                for (int i = 0; i < DataSet.Count; i++)
                {
                    if (DataSet[i].Att[j] > maxx)
                        maxx = DataSet[i].Att[j];
                    if (DataSet[i].Att[j] < minn)
                        minn = DataSet[i].Att[j];
                }
                max[j] = maxx;
                min[j] = minn;
            }

            for (int i = 0; i < DataSet.Count; i++)
            {
                for (int j = 0; j < Num_Attributes; j++)
                {
                    DataSet[i].Att[j] = ((DataSet[i].Att[j] - min[j]) / (max[j] - min[j])) * 2 - 1;
                }
                if (DataSet[i].Class == 0)
                    DataSet[i].Class = -1;
            }
        }

        private void Read_Btn_Click(object sender, EventArgs e)
        {
            DataSet.Clear();
            Train_Data.Clear();
            Valid_Data.Clear();
            Test_Data.Clear();

            StreamReader sr;
            string str_line;
            List<string> list = new List<string>();
            string Addres;
            if (DataSet_Name_Txt.SelectedIndex == 0)
            {
                Addres = "./dataset/Diabetes.txt";
                AddressW = "./Weka/Diabetes.arff";
                DataSet_Name = 0;
                Num_Attributes = 8;
                Num_Instance = 768;
                Name = "Diabetes";

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Miss_Handling();
                InformationGain ig = new InformationGain(DataSet);
                IG = ig.Run_IG();
                Data_Normalization();
                Creat_Train_Valid_Test();
                int mm = 0;
            }

            if (DataSet_Name_Txt.SelectedIndex == 1)
            {
                Addres = "./dataset/Hepatitis.txt";
                AddressW = "./Weka/Hepatitis.arff";
                DataSet_Name = 1;
                Num_Attributes = 19;
                Num_Instance = 155;
                Name = "Hepatitis";

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                Miss_Handling();
                InformationGain ig = new InformationGain(DataSet);
                IG = ig.Run_IG();
                Data_Normalization();
                Creat_Train_Valid_Test();
                int mm = 0;
            }

            if (DataSet_Name_Txt.SelectedIndex == 2)
            {
                Addres = "./dataset/Sonar.txt";
                AddressW = "./Weka/Sonar.arff";
                DataSet_Name = 2;
                Num_Attributes = 60;
                Num_Instance = 208;
                Name = "Sonar";

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                InformationGain ig = new InformationGain(DataSet);
                IG = ig.Run_IG();
                Data_Normalization();
                Creat_Train_Valid_Test();
                int mm = 0;
            }

            if (DataSet_Name_Txt.SelectedIndex == 3)
            {
                Addres = "./dataset/Cancer.txt";
                AddressW = "./Weka/Cancer.arff";
                DataSet_Name = 3;
                Num_Attributes = 9;
                Num_Instance = 699;
                Name = "Cancer";

                sr = new StreamReader(Addres);
                int i = 0;
                while (sr.EndOfStream == false)
                {
                    str_line = sr.ReadLine();
                    list.Add(str_line);
                    i++;
                }
                Create_DataSet(list, Num_Instance, Num_Attributes);
                InformationGain ig = new InformationGain(DataSet);
                IG = ig.Run_IG();
                Data_Normalization();
                Creat_Train_Valid_Test();
                int mm = 0;
            }

            Start_Btn.Enabled = true;
        }

        private void Start_Btn_Click(object sender, EventArgs e)
        {
            SW = new StreamWriter(AddressW);
            double Acc_After_SVM=0;
            double Acc_After_KNN=0;
            double Acc_After_NN=0;

            double Acc_Befor_SVM = 0;
            double Acc_Befor_KNN = 0;
            double Acc_Befor_NN = 0;



            DateTime Start_Time = DateTime.Now;
            List<Data> Selected_Feture_List = new List<Data>();
            List<Chromosome> Result = new List<Chromosome>();
            int Iteration = Convert.ToInt32(Iteration_Txt.Value);
            double Crs = Convert.ToDouble(Crossover_Txt.Value);
            double Mut = Convert.ToDouble(Mutation_Txt.Value);
            int Pop = Convert.ToInt32(Population_Txt.Value);
            int type = Convert.ToInt32(Type_Cmb.SelectedIndex);
            int It_NN = Convert.ToInt32(It_NN_Txt.Value);
            double alfa = Convert.ToDouble(Alpha_Txt.Value);
            int Hid = Convert.ToInt32(Hidden_Txt.Value);
            int Feature_Number = Convert.ToInt32(Feature_Number_Txt.Value);
            K = Feature_Number;
            if (K > Num_Attributes)
                K = Num_Attributes;
            
            //********************************************************************************************

            FS fs = new FS(Train_Data, Valid_Data, Test_Data, Crs, Mut, Iteration, Pop, Feature_Number, type, It_NN, alfa, Hid,IG, DG_Ga);
            //Acc_Befor_NN = fs.Run_NN();
            //Acc_Befor_KNN= fs.Check_KNN();
            //Acc_Befor_SVM=fs.Check_SVM();

            //Befor_NN_Txt.Text = Acc_Befor_NN.ToString();
            //Befor_KNN_Txt.Text = Acc_Befor_KNN.ToString();
            //Befor_SVM_Txt.Text = Acc_Befor_SVM.ToString();


            Result = fs.Run_FS();

            TimeSpan End = DateTime.Now.Subtract(Start_Time);
            for (int i = 0; i < Result.Count; i++)
            {
                DG_Ga.Rows.Add();
                DG_Ga.Rows[i].Cells[0].Value = i;
                DG_Ga.Rows[i].Cells[1].Value = Result[i].Fitness;
            }

            //fs.Clac_Diff_Classifier(ref Acc_After_NN, ref Acc_After_KNN, ref Acc_After_SVM);
            //After_NN_Txt.Text = (Math.Round(Acc_After_NN, 4)).ToString();
            //After_KNN_Txt.Text = (Math.Round(Acc_After_KNN, 4)).ToString();
            //After_SVM_Txt.Text = (Math.Round(Acc_After_SVM, 4)).ToString();

            Selected_Feture_List = Creat_Feature_Selected(Result[Result.Count - 1]);
            Do_Writting(Selected_Feture_List);

            int m = End.Minutes;
            int sec = End.Seconds;
            Time_Lbl.Text = ((m * 60) + sec).ToString();
            
        }

        private void Do_Writting(List<Data> l)
        {
            int I = l.Count;
            int J = l[0].Att.Length;
            SW.Write("@relation" + " " + Name);
            SW.WriteLine();
            for (int i = 0; i < K; i++)
            {
                SW.Write("@attribute " + "'" + (Selected_Feature[i]+1).ToString() + "' real");
                SW.WriteLine();
            }

            SW.Write("@attribute 'class' { -1, 1}");
            SW.WriteLine();
            SW.Write("@data");
            SW.WriteLine();

            for (int i = 0; i < I; i++)
            {
                for (int j = 0; j < J; j++)
                    SW.Write(l[i].Att[j].ToString() + ",");
                SW.Write(l[i].Class.ToString());
                SW.WriteLine();
            }
            SW.Close();
            
        }

        private List<Data> Creat_Feature_Selected(Chromosome ch)
        {
            Selected_Feature.Clear();
            List<Data> FS_Test_Data = new List<Data>();
            for (int i = 0; i < Test_Data.Count; i++)
            {
                Data D = new Data();
                D.Class = Weka_Test_Data[i].Class;
                D.Number = Weka_Test_Data[i].Number;
                D.Att = new double[K];
                int index = 0;
                for (int j = 0; j < Num_Attributes; j++)
                {
                    if (ch.genes[j] == 1)
                    {
                        D.Att[index] = Weka_Test_Data[i].Att[j];
                        index++;
                    } 
                }
                FS_Test_Data.Add(D);
            }
            for (int i = 0; i < Num_Attributes; i++)
                if (ch.genes[i] == 1)
                    Selected_Feature.Add(i);
            return FS_Test_Data;
        }

        private void Main_Load(object sender, EventArgs e)
        {
            DataSet_Name_Txt.SelectedIndex = 1;
            Type_Cmb.SelectedIndex = 3;
        }

    }
}
