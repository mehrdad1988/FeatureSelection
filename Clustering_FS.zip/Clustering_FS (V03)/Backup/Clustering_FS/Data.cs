﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clustering_FS
{
    class Data
    {

        public double[] Att;
        public int Class;
        public int Number;

        public Data()
        {

        }

    }
}
