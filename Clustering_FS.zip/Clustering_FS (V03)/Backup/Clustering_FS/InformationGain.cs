﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clustering_FS
{
    class InformationGain
    {
        List<Data> DataSet = new List<Data>();
        double[] IG;
        double[] H;
        double E;
        int Num_Att;
        List<int> []Num;
        List<double>[] Content;
        public InformationGain(List<Data> data)
        {
            DataSet = data;
            Num_Att = DataSet[0].Att.Length;
            IG = new double[Num_Att];
            Num = new List<int>[Num_Att];
            Content = new List<double>[Num_Att];
        }

        public double[] Run_IG()
        {
            double E_Sv;
            int n=DataSet.Count;
            Calc_E();
            Calc_Num_Att();

            for (int i = 0; i < Num_Att; i++)
            {
                double Sigma=0;
                for (int k = 0; k < Content[i].Count; k++)
                {
                    List<Data> Temp = new List<Data>();
                    for (int j = 0; j < n; j++)
                    {
                        if (DataSet[j].Att[i] == Content[i][k])
                            Temp.Add(DataSet[j]);
                    }
                    E_Sv = Calc_E_Sv(Temp);
                    Sigma += ((double)Temp.Count / (double)DataSet.Count) * E_Sv;
                }
                IG[i] = E - Sigma;
            }
            return IG;
        }

        void Calc_E()
        {
            int n=DataSet[0].Number;
            int[] num = new int[n];
            for (int i = 0; i < DataSet.Count; i++)
            {
                num[DataSet[i].Class]++;
            }

            double sum=0;
            int total=DataSet.Count;
            for (int i = 0; i < n; i++)
            {
                double x=(double)(num[i]/(double)total);
                double xx= Math.Log(x,2);
                sum += -1 * (x) * (xx);
            }
            E = sum;
        }

        void Calc_Num_Att()
        {
            int n = DataSet.Count;
            for (int i = 0;i< Num_Att; i++)
            {
                Num[i] = new List<int>();
                Content[i] = new List<double>();
                for (int j = 0; j < n; j++)
                {
                    bool Flag = false;
                    for (int k = 0; k < Content[i].Count; k++)
                    {
                        if (DataSet[j].Att[i] == Content[i][k])
                        {
                            Num[i][k]++;
                            Flag = true;
                        }
                    }
                    if (Flag == false)
                    {
                        Content[i].Add(DataSet[j].Att[i]);
                        Num[i].Add(1);
                    }
                }
            }
        }

        double Calc_E_Sv(List<Data> D)
        {
            int n=DataSet[0].Number;
            int[] num = new int[n];
            for (int i = 0; i < D.Count; i++)
            {
                num[D[i].Class]++;
            }

            double sum=0;
            int total=D.Count;

            for (int i = 0; i < n; i++)
                if (num[i] == 0)
                    return 0;

            for (int i = 0; i < n; i++)
            {
                double x=(double)(num[i]/(double)total);
                double xx= Math.Log(x,2);
                sum += -1 * (x) * (xx);
            }
            return sum;
        }
    }
}
