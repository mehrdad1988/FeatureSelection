﻿namespace Clustering_FS
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupPanel1 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.Feature_Number_Txt = new System.Windows.Forms.NumericUpDown();
            this.labelX9 = new DevComponents.DotNetBar.LabelX();
            this.Start_Btn = new DevComponents.DotNetBar.ButtonX();
            this.Type_Cmb = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem6 = new DevComponents.Editors.ComboItem();
            this.comboItem4 = new DevComponents.Editors.ComboItem();
            this.comboItem5 = new DevComponents.Editors.ComboItem();
            this.comboItem7 = new DevComponents.Editors.ComboItem();
            this.comboItem8 = new DevComponents.Editors.ComboItem();
            this.labelX11 = new DevComponents.DotNetBar.LabelX();
            this.DataSet_Name_Txt = new DevComponents.DotNetBar.Controls.ComboBoxEx();
            this.comboItem1 = new DevComponents.Editors.ComboItem();
            this.comboItem2 = new DevComponents.Editors.ComboItem();
            this.comboItem3 = new DevComponents.Editors.ComboItem();
            this.Read_Btn = new DevComponents.DotNetBar.ButtonX();
            this.labelX5 = new DevComponents.DotNetBar.LabelX();
            this.tabControl1 = new DevComponents.DotNetBar.TabControl();
            this.tabControlPanel1 = new DevComponents.DotNetBar.TabControlPanel();
            this.labelX1 = new DevComponents.DotNetBar.LabelX();
            this.labelX3 = new DevComponents.DotNetBar.LabelX();
            this.Iteration_Txt = new System.Windows.Forms.NumericUpDown();
            this.Mutation_Txt = new System.Windows.Forms.NumericUpDown();
            this.labelX4 = new DevComponents.DotNetBar.LabelX();
            this.Crossover_Txt = new System.Windows.Forms.NumericUpDown();
            this.Population_Txt = new System.Windows.Forms.NumericUpDown();
            this.labelX2 = new DevComponents.DotNetBar.LabelX();
            this.tabItem1 = new DevComponents.DotNetBar.TabItem(this.components);
            this.tabControlPanel2 = new DevComponents.DotNetBar.TabControlPanel();
            this.labelX6 = new DevComponents.DotNetBar.LabelX();
            this.labelX7 = new DevComponents.DotNetBar.LabelX();
            this.It_NN_Txt = new System.Windows.Forms.NumericUpDown();
            this.Hidden_Txt = new System.Windows.Forms.NumericUpDown();
            this.Alpha_Txt = new System.Windows.Forms.NumericUpDown();
            this.labelX8 = new DevComponents.DotNetBar.LabelX();
            this.tabItem2 = new DevComponents.DotNetBar.TabItem(this.components);
            this.groupPanel2 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.DG_Ga = new DevComponents.DotNetBar.Controls.DataGridViewX();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupPanel3 = new DevComponents.DotNetBar.Controls.GroupPanel();
            this.listViewEx1 = new DevComponents.DotNetBar.Controls.ListViewEx();
            this.labelX13 = new DevComponents.DotNetBar.LabelX();
            this.Befor_KNN_Txt = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.Befor_SVM_Txt = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX17 = new DevComponents.DotNetBar.LabelX();
            this.labelX16 = new DevComponents.DotNetBar.LabelX();
            this.After_KNN_Txt = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX15 = new DevComponents.DotNetBar.LabelX();
            this.After_SVM_Txt = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX14 = new DevComponents.DotNetBar.LabelX();
            this.After_NN_Txt = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX10 = new DevComponents.DotNetBar.LabelX();
            this.Befor_NN_Txt = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.Time_Lbl = new DevComponents.DotNetBar.Controls.TextBoxX();
            this.labelX12 = new DevComponents.DotNetBar.LabelX();
            this.comboItem9 = new DevComponents.Editors.ComboItem();
            this.groupPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Feature_Number_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabControl1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabControlPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Iteration_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mutation_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Crossover_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Population_Txt)).BeginInit();
            this.tabControlPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.It_NN_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Hidden_Txt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Alpha_Txt)).BeginInit();
            this.groupPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DG_Ga)).BeginInit();
            this.groupPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn1.HeaderText = "Generation";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Fitness";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 115;
            // 
            // groupPanel1
            // 
            this.groupPanel1.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel1.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel1.Controls.Add(this.Feature_Number_Txt);
            this.groupPanel1.Controls.Add(this.labelX9);
            this.groupPanel1.Controls.Add(this.Start_Btn);
            this.groupPanel1.Controls.Add(this.Type_Cmb);
            this.groupPanel1.Controls.Add(this.labelX11);
            this.groupPanel1.Controls.Add(this.DataSet_Name_Txt);
            this.groupPanel1.Controls.Add(this.Read_Btn);
            this.groupPanel1.Controls.Add(this.labelX5);
            this.groupPanel1.Controls.Add(this.tabControl1);
            this.groupPanel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.groupPanel1.Location = new System.Drawing.Point(26, 9);
            this.groupPanel1.Name = "groupPanel1";
            this.groupPanel1.Size = new System.Drawing.Size(372, 387);
            // 
            // 
            // 
            this.groupPanel1.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel1.Style.BackColorGradientAngle = 90;
            this.groupPanel1.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel1.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderBottomWidth = 1;
            this.groupPanel1.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel1.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderLeftWidth = 1;
            this.groupPanel1.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderRightWidth = 1;
            this.groupPanel1.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel1.Style.BorderTopWidth = 1;
            this.groupPanel1.Style.Class = "";
            this.groupPanel1.Style.CornerDiameter = 4;
            this.groupPanel1.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel1.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel1.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel1.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseDown.Class = "";
            this.groupPanel1.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel1.StyleMouseOver.Class = "";
            this.groupPanel1.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel1.TabIndex = 0;
            this.groupPanel1.Text = "Setting";
            // 
            // Feature_Number_Txt
            // 
            this.Feature_Number_Txt.Location = new System.Drawing.Point(184, 85);
            this.Feature_Number_Txt.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.Feature_Number_Txt.Name = "Feature_Number_Txt";
            this.Feature_Number_Txt.Size = new System.Drawing.Size(112, 24);
            this.Feature_Number_Txt.TabIndex = 22;
            this.Feature_Number_Txt.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // labelX9
            // 
            // 
            // 
            // 
            this.labelX9.BackgroundStyle.Class = "";
            this.labelX9.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX9.Location = new System.Drawing.Point(42, 85);
            this.labelX9.Name = "labelX9";
            this.labelX9.Size = new System.Drawing.Size(116, 24);
            this.labelX9.TabIndex = 21;
            this.labelX9.Text = "Feature Number:";
            // 
            // Start_Btn
            // 
            this.Start_Btn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Start_Btn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Start_Btn.Enabled = false;
            this.Start_Btn.Location = new System.Drawing.Point(122, 322);
            this.Start_Btn.Name = "Start_Btn";
            this.Start_Btn.Size = new System.Drawing.Size(107, 27);
            this.Start_Btn.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Start_Btn.TabIndex = 20;
            this.Start_Btn.Text = "Start";
            this.Start_Btn.Click += new System.EventHandler(this.Start_Btn_Click);
            // 
            // Type_Cmb
            // 
            this.Type_Cmb.DisplayMember = "Text";
            this.Type_Cmb.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.Type_Cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Type_Cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Type_Cmb.FormattingEnabled = true;
            this.Type_Cmb.ItemHeight = 16;
            this.Type_Cmb.Items.AddRange(new object[] {
            this.comboItem6,
            this.comboItem4,
            this.comboItem5,
            this.comboItem7,
            this.comboItem8});
            this.Type_Cmb.Location = new System.Drawing.Point(184, 46);
            this.Type_Cmb.Name = "Type_Cmb";
            this.Type_Cmb.Size = new System.Drawing.Size(112, 22);
            this.Type_Cmb.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Type_Cmb.TabIndex = 19;
            // 
            // comboItem6
            // 
            this.comboItem6.Text = "Classic GA";
            // 
            // comboItem4
            // 
            this.comboItem4.Text = "HGAFS";
            // 
            // comboItem5
            // 
            this.comboItem5.Text = "Threshold";
            // 
            // comboItem7
            // 
            this.comboItem7.Text = "Clustering";
            // 
            // comboItem8
            // 
            this.comboItem8.Text = "Clustering Portion";
            // 
            // labelX11
            // 
            // 
            // 
            // 
            this.labelX11.BackgroundStyle.Class = "";
            this.labelX11.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX11.Location = new System.Drawing.Point(49, 46);
            this.labelX11.Name = "labelX11";
            this.labelX11.Size = new System.Drawing.Size(109, 24);
            this.labelX11.TabIndex = 18;
            this.labelX11.Text = "Algorithm Type:";
            // 
            // DataSet_Name_Txt
            // 
            this.DataSet_Name_Txt.DisplayMember = "Text";
            this.DataSet_Name_Txt.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.DataSet_Name_Txt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.DataSet_Name_Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.DataSet_Name_Txt.FormattingEnabled = true;
            this.DataSet_Name_Txt.ItemHeight = 16;
            this.DataSet_Name_Txt.Items.AddRange(new object[] {
            this.comboItem1,
            this.comboItem2,
            this.comboItem3,
            this.comboItem9});
            this.DataSet_Name_Txt.Location = new System.Drawing.Point(184, 12);
            this.DataSet_Name_Txt.Name = "DataSet_Name_Txt";
            this.DataSet_Name_Txt.Size = new System.Drawing.Size(112, 22);
            this.DataSet_Name_Txt.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.DataSet_Name_Txt.TabIndex = 17;
            // 
            // comboItem1
            // 
            this.comboItem1.Text = "Diabetes";
            // 
            // comboItem2
            // 
            this.comboItem2.Text = "Hepatitis";
            // 
            // comboItem3
            // 
            this.comboItem3.Text = "Sonar";
            // 
            // Read_Btn
            // 
            this.Read_Btn.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton;
            this.Read_Btn.ColorTable = DevComponents.DotNetBar.eButtonColor.OrangeWithBackground;
            this.Read_Btn.Location = new System.Drawing.Point(116, 125);
            this.Read_Btn.Name = "Read_Btn";
            this.Read_Btn.Size = new System.Drawing.Size(113, 27);
            this.Read_Btn.Style = DevComponents.DotNetBar.eDotNetBarStyle.StyleManagerControlled;
            this.Read_Btn.TabIndex = 16;
            this.Read_Btn.Text = "Read";
            this.Read_Btn.Click += new System.EventHandler(this.Read_Btn_Click);
            // 
            // labelX5
            // 
            // 
            // 
            // 
            this.labelX5.BackgroundStyle.Class = "";
            this.labelX5.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX5.Location = new System.Drawing.Point(92, 12);
            this.labelX5.Name = "labelX5";
            this.labelX5.Size = new System.Drawing.Size(66, 24);
            this.labelX5.TabIndex = 15;
            this.labelX5.Text = "Data Set:";
            // 
            // tabControl1
            // 
            this.tabControl1.BackColor = System.Drawing.Color.Gainsboro;
            this.tabControl1.CanReorderTabs = true;
            this.tabControl1.Controls.Add(this.tabControlPanel1);
            this.tabControl1.Controls.Add(this.tabControlPanel2);
            this.tabControl1.Location = new System.Drawing.Point(5, 160);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedTabFont = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold);
            this.tabControl1.SelectedTabIndex = 1;
            this.tabControl1.Size = new System.Drawing.Size(340, 156);
            this.tabControl1.TabIndex = 13;
            this.tabControl1.TabLayoutType = DevComponents.DotNetBar.eTabLayoutType.FixedWithNavigationBox;
            this.tabControl1.Tabs.Add(this.tabItem1);
            this.tabControl1.Tabs.Add(this.tabItem2);
            this.tabControl1.Text = "Genetic Algorithm";
            // 
            // tabControlPanel1
            // 
            this.tabControlPanel1.Controls.Add(this.labelX1);
            this.tabControlPanel1.Controls.Add(this.labelX3);
            this.tabControlPanel1.Controls.Add(this.Iteration_Txt);
            this.tabControlPanel1.Controls.Add(this.Mutation_Txt);
            this.tabControlPanel1.Controls.Add(this.labelX4);
            this.tabControlPanel1.Controls.Add(this.Crossover_Txt);
            this.tabControlPanel1.Controls.Add(this.Population_Txt);
            this.tabControlPanel1.Controls.Add(this.labelX2);
            this.tabControlPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel1.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel1.Name = "tabControlPanel1";
            this.tabControlPanel1.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel1.Size = new System.Drawing.Size(340, 129);
            this.tabControlPanel1.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(179)))), ((int)(((byte)(231)))));
            this.tabControlPanel1.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.tabControlPanel1.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel1.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(97)))), ((int)(((byte)(156)))));
            this.tabControlPanel1.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel1.Style.GradientAngle = 90;
            this.tabControlPanel1.TabIndex = 1;
            this.tabControlPanel1.TabItem = this.tabItem1;
            // 
            // labelX1
            // 
            // 
            // 
            // 
            this.labelX1.BackgroundStyle.Class = "";
            this.labelX1.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX1.Location = new System.Drawing.Point(98, 6);
            this.labelX1.Name = "labelX1";
            this.labelX1.Size = new System.Drawing.Size(59, 22);
            this.labelX1.TabIndex = 0;
            this.labelX1.Text = "Iteration:";
            // 
            // labelX3
            // 
            // 
            // 
            // 
            this.labelX3.BackgroundStyle.Class = "";
            this.labelX3.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX3.Location = new System.Drawing.Point(58, 66);
            this.labelX3.Name = "labelX3";
            this.labelX3.Size = new System.Drawing.Size(99, 19);
            this.labelX3.TabIndex = 2;
            this.labelX3.Text = "Mutation Rate:";
            // 
            // Iteration_Txt
            // 
            this.Iteration_Txt.Location = new System.Drawing.Point(198, 8);
            this.Iteration_Txt.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.Iteration_Txt.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.Iteration_Txt.Name = "Iteration_Txt";
            this.Iteration_Txt.Size = new System.Drawing.Size(56, 24);
            this.Iteration_Txt.TabIndex = 7;
            this.Iteration_Txt.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // Mutation_Txt
            // 
            this.Mutation_Txt.DecimalPlaces = 2;
            this.Mutation_Txt.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.Mutation_Txt.Location = new System.Drawing.Point(198, 66);
            this.Mutation_Txt.Name = "Mutation_Txt";
            this.Mutation_Txt.Size = new System.Drawing.Size(56, 24);
            this.Mutation_Txt.TabIndex = 9;
            this.Mutation_Txt.Value = new decimal(new int[] {
            8,
            0,
            0,
            131072});
            // 
            // labelX4
            // 
            // 
            // 
            // 
            this.labelX4.BackgroundStyle.Class = "";
            this.labelX4.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX4.Location = new System.Drawing.Point(84, 98);
            this.labelX4.Name = "labelX4";
            this.labelX4.Size = new System.Drawing.Size(73, 19);
            this.labelX4.TabIndex = 3;
            this.labelX4.Text = "Pop Size:";
            // 
            // Crossover_Txt
            // 
            this.Crossover_Txt.DecimalPlaces = 2;
            this.Crossover_Txt.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.Crossover_Txt.Location = new System.Drawing.Point(198, 36);
            this.Crossover_Txt.Name = "Crossover_Txt";
            this.Crossover_Txt.Size = new System.Drawing.Size(56, 24);
            this.Crossover_Txt.TabIndex = 8;
            this.Crossover_Txt.Value = new decimal(new int[] {
            8,
            0,
            0,
            65536});
            // 
            // Population_Txt
            // 
            this.Population_Txt.Location = new System.Drawing.Point(198, 98);
            this.Population_Txt.Name = "Population_Txt";
            this.Population_Txt.Size = new System.Drawing.Size(56, 24);
            this.Population_Txt.TabIndex = 10;
            this.Population_Txt.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // labelX2
            // 
            // 
            // 
            // 
            this.labelX2.BackgroundStyle.Class = "";
            this.labelX2.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX2.Location = new System.Drawing.Point(37, 38);
            this.labelX2.Name = "labelX2";
            this.labelX2.Size = new System.Drawing.Size(120, 22);
            this.labelX2.TabIndex = 1;
            this.labelX2.Text = "Crossover Rate:";
            // 
            // tabItem1
            // 
            this.tabItem1.AttachedControl = this.tabControlPanel1;
            this.tabItem1.Name = "tabItem1";
            this.tabItem1.Text = "Genetic Algorithm";
            // 
            // tabControlPanel2
            // 
            this.tabControlPanel2.Controls.Add(this.labelX6);
            this.tabControlPanel2.Controls.Add(this.labelX7);
            this.tabControlPanel2.Controls.Add(this.It_NN_Txt);
            this.tabControlPanel2.Controls.Add(this.Hidden_Txt);
            this.tabControlPanel2.Controls.Add(this.Alpha_Txt);
            this.tabControlPanel2.Controls.Add(this.labelX8);
            this.tabControlPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlPanel2.Location = new System.Drawing.Point(0, 27);
            this.tabControlPanel2.Name = "tabControlPanel2";
            this.tabControlPanel2.Padding = new System.Windows.Forms.Padding(1);
            this.tabControlPanel2.Size = new System.Drawing.Size(340, 129);
            this.tabControlPanel2.Style.BackColor1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(179)))), ((int)(((byte)(231)))));
            this.tabControlPanel2.Style.BackColor2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(223)))), ((int)(((byte)(237)))), ((int)(((byte)(254)))));
            this.tabControlPanel2.Style.Border = DevComponents.DotNetBar.eBorderType.SingleLine;
            this.tabControlPanel2.Style.BorderColor.Color = System.Drawing.Color.FromArgb(((int)(((byte)(59)))), ((int)(((byte)(97)))), ((int)(((byte)(156)))));
            this.tabControlPanel2.Style.BorderSide = ((DevComponents.DotNetBar.eBorderSide)(((DevComponents.DotNetBar.eBorderSide.Left | DevComponents.DotNetBar.eBorderSide.Right)
                        | DevComponents.DotNetBar.eBorderSide.Bottom)));
            this.tabControlPanel2.Style.GradientAngle = 90;
            this.tabControlPanel2.TabIndex = 2;
            this.tabControlPanel2.TabItem = this.tabItem2;
            // 
            // labelX6
            // 
            // 
            // 
            // 
            this.labelX6.BackgroundStyle.Class = "";
            this.labelX6.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX6.Location = new System.Drawing.Point(92, 19);
            this.labelX6.Name = "labelX6";
            this.labelX6.Size = new System.Drawing.Size(59, 22);
            this.labelX6.TabIndex = 10;
            this.labelX6.Text = "Iteration:";
            // 
            // labelX7
            // 
            // 
            // 
            // 
            this.labelX7.BackgroundStyle.Class = "";
            this.labelX7.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX7.Location = new System.Drawing.Point(41, 85);
            this.labelX7.Name = "labelX7";
            this.labelX7.Size = new System.Drawing.Size(110, 19);
            this.labelX7.TabIndex = 12;
            this.labelX7.Text = "Hidden Neuron:";
            // 
            // It_NN_Txt
            // 
            this.It_NN_Txt.Location = new System.Drawing.Point(192, 21);
            this.It_NN_Txt.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.It_NN_Txt.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.It_NN_Txt.Name = "It_NN_Txt";
            this.It_NN_Txt.Size = new System.Drawing.Size(56, 24);
            this.It_NN_Txt.TabIndex = 13;
            this.It_NN_Txt.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // Hidden_Txt
            // 
            this.Hidden_Txt.Location = new System.Drawing.Point(192, 85);
            this.Hidden_Txt.Name = "Hidden_Txt";
            this.Hidden_Txt.Size = new System.Drawing.Size(56, 24);
            this.Hidden_Txt.TabIndex = 15;
            this.Hidden_Txt.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // Alpha_Txt
            // 
            this.Alpha_Txt.DecimalPlaces = 2;
            this.Alpha_Txt.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.Alpha_Txt.Location = new System.Drawing.Point(192, 52);
            this.Alpha_Txt.Name = "Alpha_Txt";
            this.Alpha_Txt.Size = new System.Drawing.Size(56, 24);
            this.Alpha_Txt.TabIndex = 14;
            this.Alpha_Txt.Value = new decimal(new int[] {
            8,
            0,
            0,
            65536});
            // 
            // labelX8
            // 
            // 
            // 
            // 
            this.labelX8.BackgroundStyle.Class = "";
            this.labelX8.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX8.Location = new System.Drawing.Point(63, 52);
            this.labelX8.Name = "labelX8";
            this.labelX8.Size = new System.Drawing.Size(88, 22);
            this.labelX8.TabIndex = 11;
            this.labelX8.Text = "Alpha Rate:";
            // 
            // tabItem2
            // 
            this.tabItem2.AttachedControl = this.tabControlPanel2;
            this.tabItem2.Name = "tabItem2";
            this.tabItem2.Text = "Neural Network";
            // 
            // groupPanel2
            // 
            this.groupPanel2.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel2.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel2.Controls.Add(this.DG_Ga);
            this.groupPanel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.groupPanel2.Location = new System.Drawing.Point(442, 13);
            this.groupPanel2.Name = "groupPanel2";
            this.groupPanel2.Size = new System.Drawing.Size(372, 383);
            // 
            // 
            // 
            this.groupPanel2.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel2.Style.BackColorGradientAngle = 90;
            this.groupPanel2.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel2.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderBottomWidth = 1;
            this.groupPanel2.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel2.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderLeftWidth = 1;
            this.groupPanel2.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderRightWidth = 1;
            this.groupPanel2.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel2.Style.BorderTopWidth = 1;
            this.groupPanel2.Style.Class = "";
            this.groupPanel2.Style.CornerDiameter = 4;
            this.groupPanel2.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel2.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel2.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel2.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel2.StyleMouseDown.Class = "";
            this.groupPanel2.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel2.StyleMouseOver.Class = "";
            this.groupPanel2.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel2.TabIndex = 1;
            this.groupPanel2.Text = "Result";
            // 
            // DG_Ga
            // 
            this.DG_Ga.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DG_Ga.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DG_Ga.DefaultCellStyle = dataGridViewCellStyle1;
            this.DG_Ga.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(215)))), ((int)(((byte)(229)))));
            this.DG_Ga.Location = new System.Drawing.Point(26, 17);
            this.DG_Ga.Name = "DG_Ga";
            this.DG_Ga.ReadOnly = true;
            this.DG_Ga.Size = new System.Drawing.Size(304, 320);
            this.DG_Ga.TabIndex = 6;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn3.HeaderText = "Generation";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 106;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Fitness";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 115;
            // 
            // groupPanel3
            // 
            this.groupPanel3.CanvasColor = System.Drawing.SystemColors.Control;
            this.groupPanel3.ColorSchemeStyle = DevComponents.DotNetBar.eDotNetBarStyle.Office2007;
            this.groupPanel3.Controls.Add(this.listViewEx1);
            this.groupPanel3.Controls.Add(this.labelX13);
            this.groupPanel3.Controls.Add(this.Befor_KNN_Txt);
            this.groupPanel3.Controls.Add(this.Befor_SVM_Txt);
            this.groupPanel3.Controls.Add(this.labelX17);
            this.groupPanel3.Controls.Add(this.labelX16);
            this.groupPanel3.Controls.Add(this.After_KNN_Txt);
            this.groupPanel3.Controls.Add(this.labelX15);
            this.groupPanel3.Controls.Add(this.After_SVM_Txt);
            this.groupPanel3.Controls.Add(this.labelX14);
            this.groupPanel3.Controls.Add(this.After_NN_Txt);
            this.groupPanel3.Controls.Add(this.labelX10);
            this.groupPanel3.Controls.Add(this.Befor_NN_Txt);
            this.groupPanel3.Controls.Add(this.Time_Lbl);
            this.groupPanel3.Controls.Add(this.labelX12);
            this.groupPanel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.groupPanel3.Location = new System.Drawing.Point(26, 421);
            this.groupPanel3.Name = "groupPanel3";
            this.groupPanel3.Size = new System.Drawing.Size(788, 240);
            // 
            // 
            // 
            this.groupPanel3.Style.BackColor2SchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground2;
            this.groupPanel3.Style.BackColorGradientAngle = 90;
            this.groupPanel3.Style.BackColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBackground;
            this.groupPanel3.Style.BorderBottom = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel3.Style.BorderBottomWidth = 1;
            this.groupPanel3.Style.BorderColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelBorder;
            this.groupPanel3.Style.BorderLeft = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel3.Style.BorderLeftWidth = 1;
            this.groupPanel3.Style.BorderRight = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel3.Style.BorderRightWidth = 1;
            this.groupPanel3.Style.BorderTop = DevComponents.DotNetBar.eStyleBorderType.Solid;
            this.groupPanel3.Style.BorderTopWidth = 1;
            this.groupPanel3.Style.Class = "";
            this.groupPanel3.Style.CornerDiameter = 4;
            this.groupPanel3.Style.CornerType = DevComponents.DotNetBar.eCornerType.Rounded;
            this.groupPanel3.Style.TextAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Center;
            this.groupPanel3.Style.TextColorSchemePart = DevComponents.DotNetBar.eColorSchemePart.PanelText;
            this.groupPanel3.Style.TextLineAlignment = DevComponents.DotNetBar.eStyleTextAlignment.Near;
            // 
            // 
            // 
            this.groupPanel3.StyleMouseDown.Class = "";
            this.groupPanel3.StyleMouseDown.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            // 
            // 
            // 
            this.groupPanel3.StyleMouseOver.Class = "";
            this.groupPanel3.StyleMouseOver.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.groupPanel3.TabIndex = 2;
            this.groupPanel3.Text = "groupPanel3";
            // 
            // listViewEx1
            // 
            this.listViewEx1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            // 
            // 
            // 
            this.listViewEx1.Border.Class = "ListViewBorder";
            this.listViewEx1.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.listViewEx1.Location = new System.Drawing.Point(674, 62);
            this.listViewEx1.Name = "listViewEx1";
            this.listViewEx1.Size = new System.Drawing.Size(43, 23);
            this.listViewEx1.TabIndex = 37;
            this.listViewEx1.UseCompatibleStateImageBehavior = false;
            // 
            // labelX13
            // 
            // 
            // 
            // 
            this.labelX13.BackgroundStyle.Class = "";
            this.labelX13.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX13.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labelX13.Location = new System.Drawing.Point(530, 62);
            this.labelX13.Name = "labelX13";
            this.labelX13.Size = new System.Drawing.Size(119, 28);
            this.labelX13.TabIndex = 36;
            this.labelX13.Text = "Selected Feature: ";
            // 
            // Befor_KNN_Txt
            // 
            this.Befor_KNN_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            // 
            // 
            // 
            this.Befor_KNN_Txt.Border.Class = "TextBoxBorder";
            this.Befor_KNN_Txt.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Befor_KNN_Txt.Enabled = false;
            this.Befor_KNN_Txt.Location = new System.Drawing.Point(224, 139);
            this.Befor_KNN_Txt.Name = "Befor_KNN_Txt";
            this.Befor_KNN_Txt.Size = new System.Drawing.Size(93, 24);
            this.Befor_KNN_Txt.TabIndex = 35;
            // 
            // Befor_SVM_Txt
            // 
            this.Befor_SVM_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            // 
            // 
            // 
            this.Befor_SVM_Txt.Border.Class = "TextBoxBorder";
            this.Befor_SVM_Txt.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Befor_SVM_Txt.Enabled = false;
            this.Befor_SVM_Txt.Location = new System.Drawing.Point(224, 100);
            this.Befor_SVM_Txt.Name = "Befor_SVM_Txt";
            this.Befor_SVM_Txt.Size = new System.Drawing.Size(93, 24);
            this.Befor_SVM_Txt.TabIndex = 34;
            // 
            // labelX17
            // 
            // 
            // 
            // 
            this.labelX17.BackgroundStyle.Class = "";
            this.labelX17.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.labelX17.Location = new System.Drawing.Point(477, 7);
            this.labelX17.Name = "labelX17";
            this.labelX17.Size = new System.Drawing.Size(146, 26);
            this.labelX17.TabIndex = 33;
            this.labelX17.Text = "Accuracy After FS:";
            // 
            // labelX16
            // 
            // 
            // 
            // 
            this.labelX16.BackgroundStyle.Class = "";
            this.labelX16.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.labelX16.Location = new System.Drawing.Point(307, 7);
            this.labelX16.Name = "labelX16";
            this.labelX16.Size = new System.Drawing.Size(146, 26);
            this.labelX16.TabIndex = 32;
            this.labelX16.Text = "Accuracy Before FS:";
            // 
            // After_KNN_Txt
            // 
            this.After_KNN_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            // 
            // 
            // 
            this.After_KNN_Txt.Border.Class = "TextBoxBorder";
            this.After_KNN_Txt.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.After_KNN_Txt.Enabled = false;
            this.After_KNN_Txt.Location = new System.Drawing.Point(393, 137);
            this.After_KNN_Txt.Name = "After_KNN_Txt";
            this.After_KNN_Txt.Size = new System.Drawing.Size(93, 24);
            this.After_KNN_Txt.TabIndex = 31;
            // 
            // labelX15
            // 
            // 
            // 
            // 
            this.labelX15.BackgroundStyle.Class = "";
            this.labelX15.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.labelX15.Location = new System.Drawing.Point(31, 138);
            this.labelX15.Name = "labelX15";
            this.labelX15.Size = new System.Drawing.Size(181, 26);
            this.labelX15.TabIndex = 30;
            this.labelX15.Text = "Accuracy After FS(KNN):";
            // 
            // After_SVM_Txt
            // 
            this.After_SVM_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            // 
            // 
            // 
            this.After_SVM_Txt.Border.Class = "TextBoxBorder";
            this.After_SVM_Txt.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.After_SVM_Txt.Enabled = false;
            this.After_SVM_Txt.Location = new System.Drawing.Point(393, 98);
            this.After_SVM_Txt.Name = "After_SVM_Txt";
            this.After_SVM_Txt.Size = new System.Drawing.Size(93, 24);
            this.After_SVM_Txt.TabIndex = 29;
            // 
            // labelX14
            // 
            // 
            // 
            // 
            this.labelX14.BackgroundStyle.Class = "";
            this.labelX14.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.labelX14.Location = new System.Drawing.Point(30, 99);
            this.labelX14.Name = "labelX14";
            this.labelX14.Size = new System.Drawing.Size(181, 26);
            this.labelX14.TabIndex = 28;
            this.labelX14.Text = "Accuracy After FS(SVM):";
            // 
            // After_NN_Txt
            // 
            this.After_NN_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            // 
            // 
            // 
            this.After_NN_Txt.Border.Class = "TextBoxBorder";
            this.After_NN_Txt.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.After_NN_Txt.Enabled = false;
            this.After_NN_Txt.Location = new System.Drawing.Point(393, 64);
            this.After_NN_Txt.Name = "After_NN_Txt";
            this.After_NN_Txt.Size = new System.Drawing.Size(93, 24);
            this.After_NN_Txt.TabIndex = 27;
            // 
            // labelX10
            // 
            // 
            // 
            // 
            this.labelX10.BackgroundStyle.Class = "";
            this.labelX10.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.labelX10.Location = new System.Drawing.Point(42, 64);
            this.labelX10.Name = "labelX10";
            this.labelX10.Size = new System.Drawing.Size(166, 26);
            this.labelX10.TabIndex = 26;
            this.labelX10.Text = "Accuracy After FS(NN):";
            // 
            // Befor_NN_Txt
            // 
            this.Befor_NN_Txt.BackColor = System.Drawing.SystemColors.InactiveCaption;
            // 
            // 
            // 
            this.Befor_NN_Txt.Border.Class = "TextBoxBorder";
            this.Befor_NN_Txt.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Befor_NN_Txt.Enabled = false;
            this.Befor_NN_Txt.Location = new System.Drawing.Point(224, 64);
            this.Befor_NN_Txt.Name = "Befor_NN_Txt";
            this.Befor_NN_Txt.Size = new System.Drawing.Size(93, 24);
            this.Befor_NN_Txt.TabIndex = 25;
            // 
            // Time_Lbl
            // 
            this.Time_Lbl.BackColor = System.Drawing.SystemColors.InactiveCaption;
            // 
            // 
            // 
            this.Time_Lbl.Border.Class = "TextBoxBorder";
            this.Time_Lbl.Border.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.Time_Lbl.Enabled = false;
            this.Time_Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.Time_Lbl.Location = new System.Drawing.Point(617, 173);
            this.Time_Lbl.Name = "Time_Lbl";
            this.Time_Lbl.Size = new System.Drawing.Size(45, 24);
            this.Time_Lbl.TabIndex = 22;
            // 
            // labelX12
            // 
            // 
            // 
            // 
            this.labelX12.BackgroundStyle.Class = "";
            this.labelX12.BackgroundStyle.CornerType = DevComponents.DotNetBar.eCornerType.Square;
            this.labelX12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.labelX12.Location = new System.Drawing.Point(530, 169);
            this.labelX12.Name = "labelX12";
            this.labelX12.Size = new System.Drawing.Size(72, 28);
            this.labelX12.TabIndex = 21;
            this.labelX12.Text = "Run Time: ";
            // 
            // comboItem9
            // 
            this.comboItem9.Text = "Cancer";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(846, 666);
            this.Controls.Add(this.groupPanel3);
            this.Controls.Add(this.groupPanel2);
            this.Controls.Add(this.groupPanel1);
            this.Name = "Main";
            this.Text = "Feature Selection";
            this.Load += new System.EventHandler(this.Main_Load);
            this.groupPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Feature_Number_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tabControl1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabControlPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Iteration_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mutation_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Crossover_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Population_Txt)).EndInit();
            this.tabControlPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.It_NN_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Hidden_Txt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Alpha_Txt)).EndInit();
            this.groupPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DG_Ga)).EndInit();
            this.groupPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel1;
        private DevComponents.DotNetBar.ButtonX Start_Btn;
        private DevComponents.DotNetBar.Controls.ComboBoxEx Type_Cmb;
        private DevComponents.Editors.ComboItem comboItem6;
        private DevComponents.Editors.ComboItem comboItem4;
        private DevComponents.Editors.ComboItem comboItem5;
        private DevComponents.DotNetBar.LabelX labelX11;
        private DevComponents.DotNetBar.Controls.ComboBoxEx DataSet_Name_Txt;
        private DevComponents.Editors.ComboItem comboItem1;
        private DevComponents.Editors.ComboItem comboItem2;
        private DevComponents.Editors.ComboItem comboItem3;
        private DevComponents.DotNetBar.ButtonX Read_Btn;
        private DevComponents.DotNetBar.LabelX labelX5;
        private DevComponents.DotNetBar.TabControl tabControl1;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel1;
        private DevComponents.DotNetBar.LabelX labelX1;
        private DevComponents.DotNetBar.LabelX labelX3;
        private System.Windows.Forms.NumericUpDown Iteration_Txt;
        private System.Windows.Forms.NumericUpDown Mutation_Txt;
        private DevComponents.DotNetBar.LabelX labelX4;
        private System.Windows.Forms.NumericUpDown Crossover_Txt;
        private System.Windows.Forms.NumericUpDown Population_Txt;
        private DevComponents.DotNetBar.LabelX labelX2;
        private DevComponents.DotNetBar.TabItem tabItem1;
        private DevComponents.DotNetBar.TabControlPanel tabControlPanel2;
        private DevComponents.DotNetBar.LabelX labelX6;
        private DevComponents.DotNetBar.LabelX labelX7;
        private System.Windows.Forms.NumericUpDown It_NN_Txt;
        private System.Windows.Forms.NumericUpDown Hidden_Txt;
        private System.Windows.Forms.NumericUpDown Alpha_Txt;
        private DevComponents.DotNetBar.LabelX labelX8;
        private DevComponents.DotNetBar.TabItem tabItem2;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel2;
        private DevComponents.DotNetBar.Controls.DataGridViewX DG_Ga;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DevComponents.Editors.ComboItem comboItem7;
        private DevComponents.Editors.ComboItem comboItem8;
        private DevComponents.DotNetBar.LabelX labelX9;
        private DevComponents.DotNetBar.Controls.GroupPanel groupPanel3;
        private DevComponents.DotNetBar.Controls.TextBoxX Befor_KNN_Txt;
        private DevComponents.DotNetBar.Controls.TextBoxX Befor_SVM_Txt;
        private DevComponents.DotNetBar.LabelX labelX17;
        private DevComponents.DotNetBar.LabelX labelX16;
        private DevComponents.DotNetBar.Controls.TextBoxX After_KNN_Txt;
        private DevComponents.DotNetBar.LabelX labelX15;
        private DevComponents.DotNetBar.Controls.TextBoxX After_SVM_Txt;
        private DevComponents.DotNetBar.LabelX labelX14;
        private DevComponents.DotNetBar.Controls.TextBoxX After_NN_Txt;
        private DevComponents.DotNetBar.LabelX labelX10;
        private DevComponents.DotNetBar.Controls.TextBoxX Befor_NN_Txt;
        private DevComponents.DotNetBar.Controls.TextBoxX Time_Lbl;
        private DevComponents.DotNetBar.LabelX labelX12;
        private System.Windows.Forms.NumericUpDown Feature_Number_Txt;
        private DevComponents.DotNetBar.Controls.ListViewEx listViewEx1;
        private DevComponents.DotNetBar.LabelX labelX13;
        private DevComponents.Editors.ComboItem comboItem9;
    }
}

