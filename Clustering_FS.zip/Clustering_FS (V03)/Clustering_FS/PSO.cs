﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clustering_FS
{
    class PSO
    {
        int Pop_Size;
        int D;
        double W;
        int max_it;
        int function_type;
        Random R = new Random();



        public PSO(int pop, int it, int d, int F)
        {
            D = d;
            Pop_Size = pop;
            max_it = it;
            function_type = F;
        }

        public List<double> RunPSO()
        {
            Solution S = new Solution(D, function_type);
            List<double> Result = new List<double>();
            double[,] Pos = new double[Pop_Size, D];
            double[,] V = new double[Pop_Size, D];
            double[] a = new double[D];
            double[] Fit = new double[Pop_Size];
            double[] best_value_i = new double[Pop_Size];
            double[,] best_pos_i = new double[Pop_Size, D];
            double best_value;
            double[] best_pos = new double[D];
            best_value = 0;
            double rand1, rand2;
            double C_Max;
            double Vmax = new double();

            if (function_type == 1)
                Vmax = 100;
            if (function_type == 2)
                Vmax = 10;
            if (function_type == 3)
                Vmax = 65;
            if (function_type == 4)
                Vmax = 5;
            if (function_type == 5)
                Vmax = 600;
            if (function_type == 6)
                Vmax = 32;



            // Iteration #1 ...
            for (int i = 0; i < Pop_Size; i++)
            {
                for (int j = 0; j < D; j++)
                {
                    Pos[i, j] = S.Generate_neighbor(0, Vmax);
                    V[i, j] = S.Generate_neighbor(0, 4 * Vmax);
                    a[j] = Pos[i, j];
                    best_pos_i[i, j] = Pos[i, j];
                }
                Fit[i] = S.Calculation(a, function_type);
                best_value_i[i] = Fit[i];
                if (i == 0)
                {
                    best_value = Fit[0];
                    for (int j = 0; j < D; j++)
                    {
                        best_pos[j] = best_pos_i[0, j];
                    }
                }
                if (Fit[i] < best_value)
                {
                    best_value = Fit[i];
                    for (int j = 0; j < D; j++)
                    {
                        best_pos[j] = best_pos_i[i, j];
                    }
                }
            }
            //End Of Iteration #1 ...

            W = 0.2;
            C_Max = 1.4;

            for (int it = 1; it < max_it; it++)
            {

                for (int i = 0; i < Pop_Size; i++)
                {

                    for (int j = 0; j < D; j++)
                    {
                        rand1 = R.NextDouble() * C_Max;
                        rand2 = R.NextDouble() * C_Max;

                        V[i, j] = W * V[i, j] + rand1 * (best_pos_i[i, j] - Pos[i, j]) + rand2 * (best_pos[j] - Pos[i, j]);
                        if (V[i, j] > 2 * Vmax)
                            V[i, j] = 2 * Vmax;
                        if (V[i, j] < -2 * Vmax)
                            V[i, j] = -2 * Vmax;
                    }

                    for (int j = 0; j < D; j++)
                    {
                        Pos[i, j] = Pos[i, j] + V[i, j];
                        if (Pos[i, j] > Vmax)
                            Pos[i, j] = Vmax;
                        if (Pos[i, j] < -1 * Vmax)
                            Pos[i, j] = -1 * Vmax;

                        a[j] = Pos[i, j];
                    }
                    Fit[i] = S.Calculation(a, function_type);
                    if (Fit[i] < best_value_i[i])
                    {
                        best_value_i[i] = Fit[i];
                        for (int j = 0; j < D; j++)
                            best_pos_i[i, j] = Pos[i, j];
                    }
                    if (Fit[i] < best_value)
                    {
                        best_value = Fit[i];
                        for (int j = 0; j < D; j++)
                            best_pos[j] = Pos[i, j];

                        Result.Add(best_value);
                    }

                }
            }
            return Result;
        }
    }
}
